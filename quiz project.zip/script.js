/* QUIZORA – quiz logic. Vanilla JavaScript, no libraries. */
(function () {
  'use strict';

  /* ---------- Question database ----------
     "answer" is the index (0-3) of the correct option. */
  var QUESTIONS = [
    { category: 'Technology', question: 'What does HTTP stand for?',
      options: ['HyperText Transfer Protocol', 'High Transfer Text Process', 'Hyperlink Text Transmission Program', 'Host Transfer Technology Protocol'], answer: 0 },
    { category: 'Technology', question: 'Which data structure follows the Last In, First Out (LIFO) rule?',
      options: ['Queue', 'Array', 'Stack', 'Binary tree'], answer: 2 },
    { category: 'Technology', question: 'What is the binary number 1010 in decimal?',
      options: ['8', '12', '14', '10'], answer: 3 },
    { category: 'Technology', question: 'What does a compiler do?',
      options: ['Translates source code into machine code before it runs', 'Stores web pages on a server', 'Fixes bugs in a program automatically', 'Connects a computer to the internet'], answer: 0 },
    { category: 'Technology', question: 'Which company originally developed the Java language?',
      options: ['Microsoft', 'Sun Microsystems', 'Apple', 'IBM'], answer: 1 },

    { category: 'Science', question: 'Which gas do plants absorb from the air for photosynthesis?',
      options: ['Oxygen', 'Nitrogen', 'Hydrogen', 'Carbon dioxide'], answer: 3 },
    { category: 'Science', question: 'What is the chemical symbol for gold?',
      options: ['Au', 'Ag', 'Gd', 'Go'], answer: 0 },
    { category: 'Science', question: 'Approximately how fast does light travel in a vacuum?',
      options: ['3 × 10⁶ m/s', '3 × 10⁸ m/s', '3 × 10¹⁰ m/s', '3 × 10⁵ m/s'], answer: 1 },
    { category: 'Science', question: 'What is the SI unit of force?',
      options: ['Joule', 'Watt', 'Pascal', 'Newton'], answer: 3 },
    { category: 'Science', question: 'Which part of a cell is known as its powerhouse?',
      options: ['Nucleus', 'Mitochondria', 'Ribosome', 'Cell wall'], answer: 1 },

    { category: 'General Knowledge', question: 'What is the capital city of Australia?',
      options: ['Sydney', 'Melbourne', 'Canberra', 'Perth'], answer: 2 },
    { category: 'General Knowledge', question: 'Who wrote the book "The Discovery of India"?',
      options: ['Jawaharlal Nehru', 'Mahatma Gandhi', 'Rabindranath Tagore', 'S. Radhakrishnan'], answer: 0 },
    { category: 'General Knowledge', question: 'Which is the largest ocean on Earth?',
      options: ['Atlantic Ocean', 'Indian Ocean', 'Arctic Ocean', 'Pacific Ocean'], answer: 3 },
    { category: 'General Knowledge', question: 'Which country hosted the 2024 Summer Olympics?',
      options: ['Japan', 'France', 'United States', 'Australia'], answer: 1 },
    { category: 'General Knowledge', question: 'What is the national animal of India?',
      options: ['Lion', 'Elephant', 'Bengal tiger', 'Leopard'], answer: 2 }
  ];

  var LETTERS = ['A', 'B', 'C', 'D'];

  /* ---------- App state ---------- */
  var state = { category: null, questions: [], answers: [], current: 0, submitted: false };

  function $(id) { return document.getElementById(id); }

  /* ---------- Screen switching ---------- */
  function showScreen(id) {
    ['welcome', 'quiz', 'results'].forEach(function (name) {
      $(name).classList.toggle('active', name === id);
    });
    window.scrollTo(0, 0);
  }

  /* ---------- Welcome screen ---------- */
  function selectCategory(button) {
    state.category = button.getAttribute('data-category');
    document.querySelectorAll('.cat').forEach(function (cat) {
      cat.setAttribute('aria-checked', String(cat === button));
    });
    $('startMsg').textContent = '';
  }

  function startQuiz() {
    if (!state.category) {
      $('startMsg').textContent = 'Pick a category first.';
      return;
    }
    state.questions = QUESTIONS.filter(function (q) { return q.category === state.category; });
    state.answers = state.questions.map(function () { return null; }); // null = unanswered
    state.current = 0;
    state.submitted = false;
    $('quizMsg').textContent = '';
    $('quizCategory').textContent = state.category;
    showScreen('quiz');
    renderQuestion();
  }

  /* ---------- Quiz screen ---------- */
  function renderQuestion() {
    var total = state.questions.length;
    var q = state.questions[state.current];
    var isLast = state.current === total - 1;

    $('quizCount').textContent = 'Question ' + (state.current + 1) + ' of ' + total;
    $('questionText').textContent = q.question;

    // Progress = how many questions have been answered
    var answered = countAnswered();
    var percent = Math.round((answered / total) * 100);
    $('progressFill').style.width = percent + '%';
    $('progress').setAttribute('aria-valuenow', String(percent));

    renderOptions(q);
    renderDots();

    $('prevBtn').disabled = state.current === 0;
    $('nextBtn').style.display = isLast ? 'none' : '';
    $('submitBtn').style.display = isLast ? 'inline-block' : 'none';
    $('submitBtn').disabled = state.submitted;
  }

  function renderOptions(q) {
    var box = $('options');
    box.innerHTML = '';
    q.options.forEach(function (text, i) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'option' + (state.answers[state.current] === i ? ' selected' : '');
      btn.setAttribute('aria-pressed', String(state.answers[state.current] === i));
      var key = document.createElement('span');
      key.className = 'key';
      key.textContent = LETTERS[i];
      var label = document.createElement('span');
      label.textContent = text;
      btn.appendChild(key);
      btn.appendChild(label);
      btn.addEventListener('click', function () { chooseAnswer(i); });
      box.appendChild(btn);
    });
  }

  function renderDots() {
    var box = $('dots');
    box.innerHTML = '';
    state.questions.forEach(function (q, i) {
      var dot = document.createElement('button');
      dot.type = 'button';
      dot.className = 'dot' + (state.answers[i] !== null ? ' answered' : '') + (i === state.current ? ' current' : '');
      dot.textContent = i + 1;
      dot.setAttribute('aria-label', 'Go to question ' + (i + 1));
      dot.addEventListener('click', function () { goTo(i); });
      box.appendChild(dot);
    });
  }

  function countAnswered() {
    return state.answers.filter(function (a) { return a !== null; }).length;
  }

  function chooseAnswer(optionIndex) {
    if (state.submitted) return;
    state.answers[state.current] = optionIndex; // overwrites any earlier choice
    $('quizMsg').textContent = '';
    renderQuestion();
  }

  function goTo(index) {
    if (index < 0 || index >= state.questions.length) return;
    state.current = index;
    $('quizMsg').textContent = '';
    renderQuestion();
  }

  /* ---------- Submit and score ---------- */
  function submitQuiz() {
    if (state.submitted) return; // blocks double submissions

    var missing = [];
    state.answers.forEach(function (a, i) { if (a === null) missing.push(i + 1); });
    if (missing.length > 0) {
      $('quizMsg').textContent = 'Answer every question before submitting. Still open: ' + missing.join(', ') + '.';
      return;
    }
    state.submitted = true;
    showResults(calculateResult());
  }

  function calculateResult() {
    var correct = 0;
    state.questions.forEach(function (q, i) { if (state.answers[i] === q.answer) correct++; });
    var total = state.questions.length;
    return { correct: correct, wrong: total - correct, total: total, percent: Math.round((correct / total) * 100) };
  }

  function getMessage(percent) {
    if (percent >= 90) return { title: 'Outstanding!', sub: 'Near-perfect. You clearly know this topic.' };
    if (percent >= 70) return { title: 'Great Work!', sub: 'A strong result. A little revision and you will ace it.' };
    if (percent >= 50) return { title: 'Not Bad!', sub: 'You have the basics. Check the review below to close the gaps.' };
    return { title: 'Keep Practising!', sub: 'Every quiz teaches you something. Read the review and try again.' };
  }

  /* ---------- Results screen ---------- */
  function showResults(result) {
    var msg = getMessage(result.percent);
    $('scoreText').textContent = result.correct + ' / ' + result.total;
    $('ring').style.setProperty('--pct', result.percent);
    $('resultTitle').textContent = msg.title;
    $('resultSub').textContent = msg.sub;
    $('statCorrect').textContent = result.correct;
    $('statWrong').textContent = result.wrong;
    $('statAttempted').textContent = countAnswered() + ' of ' + result.total;
    $('statPercent').textContent = result.percent + '%';
    renderReview();
    showScreen('results');
  }

  function addLine(parent, label, text, cls) {
    var p = document.createElement('p');
    p.appendChild(document.createTextNode(label + ' '));
    var span = document.createElement('span');
    span.textContent = text;
    if (cls) span.className = cls;
    p.appendChild(span);
    parent.appendChild(p);
  }

  function renderReview() {
    var list = $('review');
    list.innerHTML = '';
    state.questions.forEach(function (q, i) {
      var isRight = state.answers[i] === q.answer;
      var li = document.createElement('li');
      li.className = isRight ? 'right' : 'wrong';
      var title = document.createElement('p');
      title.className = 'q';
      title.textContent = (i + 1) + '. ' + q.question;
      li.appendChild(title);
      addLine(li, 'Your answer:', q.options[state.answers[i]], isRight ? 'good' : 'bad');
      if (!isRight) addLine(li, 'Correct answer:', q.options[q.answer], 'good');
      list.appendChild(li);
    });
  }

  /* ---------- Navigation helpers ---------- */
  function goHome() {
    state.category = null;
    document.querySelectorAll('.cat').forEach(function (cat) { cat.setAttribute('aria-checked', 'false'); });
    $('startMsg').textContent = '';
    showScreen('welcome');
  }

  /* ---------- Event wiring ---------- */
  document.querySelectorAll('.cat').forEach(function (btn) {
    btn.addEventListener('click', function () { selectCategory(btn); });
  });
  $('startBtn').addEventListener('click', startQuiz);
  $('prevBtn').addEventListener('click', function () { goTo(state.current - 1); });
  $('nextBtn').addEventListener('click', function () { goTo(state.current + 1); });
  $('submitBtn').addEventListener('click', submitQuiz);
  $('retryBtn').addEventListener('click', startQuiz); // same category, fresh answers
  $('homeBtn').addEventListener('click', goHome);
  $('brandBtn').addEventListener('click', goHome);
})();
